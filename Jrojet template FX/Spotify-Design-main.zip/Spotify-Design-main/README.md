# Spotify-Design
# Tutorial
Watch the full Tutorial on my youtube channel:
https://youtu.be/j1NckmvPJSA

# Screenshot
![alt text](https://raw.githubusercontent.com/mahmoudhamwi/Spotify-Design/main/Spotify/src/ScreenShots/spotify.PNG)
